#ifndef ERROR_CHECK
#define ERROR_CHECK
#include "globals.h"

FILE *check_args(int argc, char *argv[]);
void error_print(void);

#endif
