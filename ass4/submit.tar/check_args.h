#ifndef GLOBALS
#include "globals.h"
#endif

#ifndef ERROR_CHECK
#define ERROR_CHECK

FILE *check_args(int argc, char *argv[]);
void error_print(void);

#endif
